import os
import gymnasium as gym
from stable_baselines3 import DQN

base_dir = "C:\\Users\\21753\\Desktop\\RL1"  # RL1 项目路径
model_dir = os.path.join(base_dir, "models")  # 绝对路径：models 目录
model_path = os.path.join(model_dir, "dqn_cartpole.zip")  # 绝对路径：模型文件

# 检查模型是否存在
if not os.path.exists(model_path):
    raise FileNotFoundError(f" 模型文件 {model_path} 不存在，请先运行 `train.py` 训练模型！")

# 创建 Gym 环境
env = gym.make("CartPole-v1", render_mode="human")

# 加载训练好的模型
model = DQN.load(model_path)

# 智能体函数，运行5000次
obs, _ = env.reset()
for _ in range(5000):
    action, _ = model.predict(obs)
    obs, reward, done, _, _ = env.step(action)
    env.render()
    if done:
        break

env.close()
print(" 测试完成，智能体已运行 5000 步！")
