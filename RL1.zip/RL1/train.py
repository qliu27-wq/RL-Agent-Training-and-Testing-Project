

import os
import gymnasium as gym
from stable_baselines3 import DQN

# 创建 Gym 环境
env = gym.make("CartPole-v1")

# 创建 DQN 强化学习模型
model = DQN("MlpPolicy", env, verbose=1)

# 训练 100w 步
model.learn(total_timesteps=1000000, progress_bar=True)

# 获取**绝对路径**：存放模型的目录
base_dir = "C:\\Users\\21753\\Desktop\\RL1"  # 你的 RL 项目路径
model_dir = os.path.join(base_dir, "models")  # 绝对路径：models 目录
os.makedirs(model_dir, exist_ok=True)  # 确保文件夹存在

# **保存模型到绝对路径**
model_path = os.path.join(model_dir, "dqn_cartpole.zip")
model.save(model_path)

env.close()
print(f"训练完成，模型已保存到: {model_path}")
